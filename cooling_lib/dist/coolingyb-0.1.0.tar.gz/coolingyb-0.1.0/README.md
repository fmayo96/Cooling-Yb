### CoolingYb

A simple python module that allows one to calculate the net power and efficiency of multimode laser cooling of Yb+3 doped crystals. 